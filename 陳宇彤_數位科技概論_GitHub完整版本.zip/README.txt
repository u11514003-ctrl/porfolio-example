# 陳宇彤｜數位科技概論個人作品集

GitHub Pages 建議結構：

```text
專案根目錄/
├── index.html
└── assignments/
    └── assignment01.html
```

請把 `index.html` 放在專案最外層，並建立 `assignments` 資料夾，把 `assignment01.html` 放進去。

作品集第一個作業的連結已設定為：
`assignments/assignment01.html`
